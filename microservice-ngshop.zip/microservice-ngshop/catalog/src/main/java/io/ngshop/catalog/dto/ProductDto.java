package io.ngshop.catalog.dto;

public class ProductDto {

}
