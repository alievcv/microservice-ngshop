rootProject.name = "admin-service"
