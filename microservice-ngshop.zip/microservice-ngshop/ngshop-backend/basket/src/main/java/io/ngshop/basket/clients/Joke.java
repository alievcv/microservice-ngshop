package io.ngshop.basket.clients;

public record Joke(String type, String setup, String punchline, String id) {
}
