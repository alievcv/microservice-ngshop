rootProject.name = "spring-cloud-api-gateway"
