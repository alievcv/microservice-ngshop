package io.ngshop.ordering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
