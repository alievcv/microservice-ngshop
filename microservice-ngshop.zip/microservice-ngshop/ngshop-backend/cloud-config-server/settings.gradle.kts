rootProject.name = "cloud-config-server"
